# George v1 Architecture

```text
Android phone
│
├── George identity core
├── Local SQLite memory
├── Local conversation history
├── Secure credential store (Android Keystore)
├── Export / restore backups
│
└── Replaceable reasoning engine
    └── OpenAI Responses API (optional in v0.1)
```

## Memory flow

```text
User message
   ↓
Save locally
   ↓
Find relevant local memories
   ↓
George Core + relevant memories + recent conversation
   ↓
Reasoning engine (only if connected)
   ↓
Answer
   ↓
Save answer locally
```

## Control principle

The user can review, add, delete, export, and restore long-term memory. Credentials are not part of backup exports.
