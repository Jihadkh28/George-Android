# George Living Memory — Android v0.1

This is the first native Android foundation for **George**: a portable, user-owned identity and memory layer with an optional replaceable AI reasoning engine.

## What is already implemented

- Native Android app shell named **George**.
- Local SQLite long-term memory database.
- Local chat history.
- Bundled `george_core.md` identity/continuity file.
- Seed memories for the George project.
- `/remember ...` command for explicit durable local memory.
- Memory browser, manual add, and delete.
- Export George memory to a portable JSON backup.
- Restore/merge a George JSON backup.
- Optional OpenAI Responses API connection.
- API key encryption using Android Keystore; no API key is embedded in source or APK.
- Model field is configurable; default is `gpt-5.6-luna` to reduce API cost.
- OpenAI request uses `store: false`.
- AI context is assembled from George Core + relevant local memories + recent local messages.

## Important architecture decision

**The Android phone owns George's continuity.** The cloud model is treated as a replaceable reasoning engine. This allows future migration to another model/provider while retaining George's identity and local memory.

## Build requirements

- Android Studio / Android SDK API 37
- Android Gradle Plugin 9.4.0
- Gradle 9.6.1
- JDK 17+

This source package intentionally has no third-party runtime libraries.

## Current limitations of v0.1

- No voice yet.
- No automatic AI-based memory consolidation yet; explicit `/remember` and manual memories are safer for the first build.
- No JKVIN/JKPATTERN knowledge import yet.
- `george_core.md` is bundled/read-only in this first version.
- No biometric lock yet.
- The project source is complete, but a compiled APK requires an Android SDK/build runner.

## Planned next layers

1. Editable/versioned George Core.
2. Automatic memory suggestions with user approval.
3. Encrypted full-database backup.
4. Voice conversation.
5. JKVIN/JKPATTERN knowledge packs.
6. Files/camera tools.
7. Offline/local model fallback.
8. Provider switcher so George is not tied to one AI company.

## Automated APK build (GitHub Actions)
This source now includes `.github/workflows/build-apk.yml`. When pushed to GitHub, the workflow installs the Android SDK, uses Gradle 9.6.1, builds the debug APK, and uploads `app-debug.apk` as a workflow artifact named `George-Android-v0.1-debug`.
