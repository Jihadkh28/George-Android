package com.george.livingmemory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class MemoryDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "george_memory.db";
    private static final int DB_VERSION = 1;

    public MemoryDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE memories (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "type TEXT NOT NULL," +
                "topic TEXT NOT NULL," +
                "content TEXT NOT NULL," +
                "importance REAL NOT NULL DEFAULT 0.5," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE messages (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "role TEXT NOT NULL," +
                "content TEXT NOT NULL," +
                "created_at INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Versioned migrations will be added as George evolves.
    }

    public long addMemory(String type, String topic, String content, double importance) {
        long now = System.currentTimeMillis();
        ContentValues v = new ContentValues();
        v.put("type", type);
        v.put("topic", topic);
        v.put("content", content);
        v.put("importance", Math.max(0.0, Math.min(1.0, importance)));
        v.put("created_at", now);
        v.put("updated_at", now);
        return getWritableDatabase().insert("memories", null, v);
    }

    public void updateMemory(long id, String type, String topic, String content, double importance) {
        ContentValues v = new ContentValues();
        v.put("type", type);
        v.put("topic", topic);
        v.put("content", content);
        v.put("importance", Math.max(0.0, Math.min(1.0, importance)));
        v.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().update("memories", v, "id=?", new String[]{String.valueOf(id)});
    }

    public void deleteMemory(long id) {
        getWritableDatabase().delete("memories", "id=?", new String[]{String.valueOf(id)});
    }

    public List<MemoryItem> getAllMemories() {
        List<MemoryItem> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,type,topic,content,importance,created_at,updated_at FROM memories ORDER BY importance DESC, updated_at DESC",
                null)) {
            while (c.moveToNext()) {
                out.add(new MemoryItem(
                        c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                        c.getDouble(4), c.getLong(5), c.getLong(6)));
            }
        }
        return out;
    }

    public List<MemoryItem> relevantMemories(String query, int limit) {
        List<MemoryItem> all = getAllMemories();
        String[] words = query.toLowerCase().replaceAll("[^\\p{L}\\p{N}]+", " ").trim().split("\\s+");
        all.sort((a, b) -> Double.compare(score(b, words), score(a, words)));
        if (all.size() > limit) return new ArrayList<>(all.subList(0, limit));
        return all;
    }

    private double score(MemoryItem m, String[] words) {
        String text = (m.topic + " " + m.content + " " + m.type).toLowerCase();
        double score = m.importance * 2.0;
        for (String w : words) {
            if (w.length() >= 3 && text.contains(w)) score += 1.0;
        }
        return score;
    }

    public long addMessage(String role, String content) {
        ContentValues v = new ContentValues();
        v.put("role", role);
        v.put("content", content);
        v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("messages", null, v);
    }

    public List<String[]> recentMessages(int limit) {
        List<String[]> reversed = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT role,content FROM messages ORDER BY id DESC LIMIT ?",
                new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) reversed.add(new String[]{c.getString(0), c.getString(1)});
        }
        List<String[]> ordered = new ArrayList<>();
        for (int i = reversed.size() - 1; i >= 0; i--) ordered.add(reversed.get(i));
        return ordered;
    }

    public void clearMessages() {
        getWritableDatabase().delete("messages", null, null);
    }

    public void clearMemories() {
        getWritableDatabase().delete("memories", null, null);
    }
}
