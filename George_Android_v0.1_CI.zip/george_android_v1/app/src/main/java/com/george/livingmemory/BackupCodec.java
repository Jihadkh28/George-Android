package com.george.livingmemory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class BackupCodec {
    public static String exportJson(String core, List<MemoryItem> memories) throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "george-living-memory");
        root.put("schema_version", 1);
        root.put("exported_at", System.currentTimeMillis());
        root.put("core", core);
        JSONArray arr = new JSONArray();
        for (MemoryItem m : memories) {
            JSONObject o = new JSONObject();
            o.put("type", m.type);
            o.put("topic", m.topic);
            o.put("content", m.content);
            o.put("importance", m.importance);
            o.put("created_at", m.createdAt);
            o.put("updated_at", m.updatedAt);
            arr.put(o);
        }
        root.put("memories", arr);
        return root.toString(2);
    }

    public static int importMemories(String json, MemoryDb db, boolean replace) throws Exception {
        JSONObject root = new JSONObject(json);
        if (!"george-living-memory".equals(root.optString("format"))) {
            throw new Exception("This is not a George memory backup.");
        }
        if (replace) db.clearMemories();
        JSONArray arr = root.optJSONArray("memories");
        if (arr == null) return 0;
        int count = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            db.addMemory(
                    o.optString("type", "memory"),
                    o.optString("topic", "general"),
                    o.optString("content", ""),
                    o.optDouble("importance", 0.5));
            count++;
        }
        return count;
    }
}
