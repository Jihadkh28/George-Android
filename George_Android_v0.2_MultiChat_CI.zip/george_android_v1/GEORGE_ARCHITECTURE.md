# George v0.2 Architecture

```text
Android phone
│
├── George identity core
├── Shared long-term memory
├── Chats
│   ├── Chat A → its own messages
│   ├── Chat B → its own messages
│   └── Chat C → its own messages
├── Secure credential store (Android Keystore)
├── Export / restore backups
│
└── Replaceable reasoning engine
    └── OpenAI Responses API (optional)
```

## Conversation flow

```text
User opens/creates a chat
   ↓
Message saved with chat_id
   ↓
Find relevant shared long-term memories
   ↓
George Core + relevant memories + recent messages from this chat only
   ↓
Reasoning engine (only if connected)
   ↓
Answer saved back to the same chat
```

## Continuity model

- **Identity Core:** who George is and how he should operate.
- **Long-term memory:** durable knowledge shared across chats.
- **Chat history:** separate short-term conversational threads.
- **Credentials:** stored separately in Android Keystore and never exported.

Deleting or clearing a chat never deletes George's long-term memory.
