# George Living Memory — Android v0.2

This is the native Android foundation for **George**: a portable, user-owned identity and long-term memory layer with an optional replaceable AI reasoning engine.

## What v0.2 adds

- Proper **multi-chat conversations**.
- `+ New chat` from the chat header and menu.
- Chat history screen with automatic titles and timestamps.
- Open, rename, and delete individual chats.
- Existing v0.1 single-thread messages migrate into **Previous chat**.
- George's long-term memory stays separate from chat history and is shared across all chats.
- Clearing/deleting a chat does not erase long-term memory.
- AI context uses only the current chat's recent messages plus relevant long-term memory.
- Backup schema v2 exports **long-term memory + chats + messages**.
- Restore supports both v1 memory-only backups and v2 backups.
- API keys remain excluded from backups.

## Existing foundations retained

- Native Android app shell named **George**.
- Local SQLite long-term memory database.
- Bundled `george_core.md` identity/continuity file.
- `/remember ...` command for explicit durable local memory.
- Memory browser, manual add, and delete.
- Optional OpenAI Responses API connection.
- API key encryption using Android Keystore; no API key is embedded in source or APK.
- Model field is configurable; default is `gpt-5.6-luna`.
- OpenAI request uses `store: false`.

## Architecture principle

**The Android phone owns George's continuity.** Individual chats are temporary conversation contexts. George Core and long-term memory are separate continuity layers, so starting a new chat does not make George forget durable information.

## Build requirements

- Android SDK API 36/37
- Android Gradle Plugin 9.4.0
- Gradle 9.6.1
- JDK 17+

This source package intentionally has no third-party runtime libraries.

## Automated APK build

The repository workflow unpacks this source, uses Android API 36 on GitHub Actions, builds the debug APK, and uploads it as an artifact.
