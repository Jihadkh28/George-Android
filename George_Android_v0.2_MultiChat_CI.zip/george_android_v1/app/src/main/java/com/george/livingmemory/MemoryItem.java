package com.george.livingmemory;

public class MemoryItem {
    public long id;
    public String type;
    public String topic;
    public String content;
    public double importance;
    public long createdAt;
    public long updatedAt;

    public MemoryItem(long id, String type, String topic, String content,
                      double importance, long createdAt, long updatedAt) {
        this.id = id;
        this.type = type;
        this.topic = topic;
        this.content = content;
        this.importance = importance;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
}
