package com.george.livingmemory;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CoreLoader {
    public static String readAsset(Context context, String name) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(context.getAssets().open(name)))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
