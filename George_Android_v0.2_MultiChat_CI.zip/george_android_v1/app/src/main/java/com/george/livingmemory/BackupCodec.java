package com.george.livingmemory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class BackupCodec {
    public static String exportJson(String core, List<MemoryItem> memories, MemoryDb db) throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "george-living-memory");
        root.put("schema_version", 2);
        root.put("exported_at", System.currentTimeMillis());
        root.put("core", core);

        JSONArray memoryArr = new JSONArray();
        for (MemoryItem m : memories) {
            JSONObject o = new JSONObject();
            o.put("type", m.type);
            o.put("topic", m.topic);
            o.put("content", m.content);
            o.put("importance", m.importance);
            o.put("created_at", m.createdAt);
            o.put("updated_at", m.updatedAt);
            memoryArr.put(o);
        }
        root.put("memories", memoryArr);

        JSONArray chatsArr = new JSONArray();
        for (ChatItem chat : db.getChats()) {
            JSONObject c = new JSONObject();
            c.put("title", chat.title);
            c.put("created_at", chat.createdAt);
            c.put("updated_at", chat.updatedAt);
            JSONArray msgs = new JSONArray();
            for (String[] msg : db.allMessagesForBackup(chat.id)) {
                JSONObject m = new JSONObject();
                m.put("role", msg[0]);
                m.put("content", msg[1]);
                try {
                    m.put("created_at", Long.parseLong(msg[2]));
                } catch (Exception ignored) {
                    m.put("created_at", System.currentTimeMillis());
                }
                msgs.put(m);
            }
            c.put("messages", msgs);
            chatsArr.put(c);
        }
        root.put("chats", chatsArr);
        return root.toString(2);
    }

    public static ImportResult importBackup(String json, MemoryDb db, boolean replace) throws Exception {
        JSONObject root = new JSONObject(json);
        if (!"george-living-memory".equals(root.optString("format"))) {
            throw new Exception("This is not a George memory backup.");
        }

        if (replace) {
            db.clearMemories();
            db.clearChats();
        }

        int memoryCount = 0;
        JSONArray arr = root.optJSONArray("memories");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                db.addMemoryWithTimestamps(
                        o.optString("type", "memory"),
                        o.optString("topic", "general"),
                        o.optString("content", ""),
                        o.optDouble("importance", 0.5),
                        o.optLong("created_at", System.currentTimeMillis()),
                        o.optLong("updated_at", System.currentTimeMillis()));
                memoryCount++;
            }
        }

        int chatCount = 0;
        int messageCount = 0;
        JSONArray chats = root.optJSONArray("chats");
        if (chats != null) {
            for (int i = 0; i < chats.length(); i++) {
                JSONObject c = chats.optJSONObject(i);
                if (c == null) continue;
                long chatId = db.createChatWithTimestamps(
                        c.optString("title", "Restored chat"),
                        c.optLong("created_at", System.currentTimeMillis()),
                        c.optLong("updated_at", System.currentTimeMillis()));
                chatCount++;
                JSONArray msgs = c.optJSONArray("messages");
                if (msgs == null) continue;
                for (int j = 0; j < msgs.length(); j++) {
                    JSONObject m = msgs.optJSONObject(j);
                    if (m == null) continue;
                    db.addMessageWithTimestamp(
                            chatId,
                            m.optString("role", "assistant"),
                            m.optString("content", ""),
                            m.optLong("created_at", System.currentTimeMillis()));
                    messageCount++;
                }
            }
        }

        db.ensureDefaultChat();
        return new ImportResult(memoryCount, chatCount, messageCount);
    }

    public static class ImportResult {
        public final int memories;
        public final int chats;
        public final int messages;

        public ImportResult(int memories, int chats, int messages) {
            this.memories = memories;
            this.chats = chats;
            this.messages = messages;
        }
    }
}
