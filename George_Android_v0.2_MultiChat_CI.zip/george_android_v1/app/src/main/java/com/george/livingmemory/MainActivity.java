package com.george.livingmemory;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT = 501;
    private static final int REQ_IMPORT = 502;

    private MemoryDb db;
    private SecureStore secureStore;
    private String georgeCore = "";
    private LinearLayout root;
    private LinearLayout messages;
    private ScrollView chatScroll;
    private EditText input;
    private TextView chatTitleView;
    private long currentChatId;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private String pendingExport = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new MemoryDb(this);
        secureStore = new SecureStore(this);
        try {
            georgeCore = CoreLoader.readAsset(this, "george_core.md");
            seedMemoriesIfNeeded();
        } catch (Exception e) {
            georgeCore = "You are George, a warm and practical digital companion.";
        }

        currentChatId = getPreferences().getLong("current_chat_id", 0);
        if (!db.chatExists(currentChatId)) currentChatId = db.ensureDefaultChat();
        saveCurrentChat();
        showChat();
    }

    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(dp(12), dp(8), dp(12), dp(8));
        return v;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private void baseScreen(String title) {
        baseScreen(title, false);
    }

    private void baseScreen(String title, boolean chatHeader) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(16,20,24));
        root.setPadding(dp(10), dp(10), dp(10), dp(10));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(title, 22, Color.rgb(244,247,249));
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        if (chatHeader) {
            Button add = button("＋");
            add.setContentDescription("New chat");
            add.setOnClickListener(v -> createNewChat());
            header.addView(add);
        }

        Button menu = button("☰");
        menu.setOnClickListener(v -> showMenu());
        header.addView(menu);
        root.addView(header);
    }

    private void showChat() {
        if (!db.chatExists(currentChatId)) {
            currentChatId = db.ensureDefaultChat();
            saveCurrentChat();
        }

        baseScreen("George", true);

        chatTitleView = text("💬 " + db.getChatTitle(currentChatId), 14, Color.rgb(210,218,224));
        root.addView(chatTitleView);

        TextView status = text(apiConfigured() ? "● Brain connected" : "○ Local memory mode", 13,
                apiConfigured() ? Color.rgb(123,223,242) : Color.rgb(170,182,191));
        root.addView(status);

        chatScroll = new ScrollView(this);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, dp(8), 0, dp(8));
        chatScroll.addView(messages);
        root.addView(chatScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        List<String[]> recent = db.recentMessages(currentChatId, 40);
        if (recent.isEmpty()) {
            addBubble("assistant", "New conversation, same George. My long-term memory stays available across chats.");
        } else {
            for (String[] msg : recent) addBubble(msg[0], msg[1]);
        }

        LinearLayout composer = new LinearLayout(this);
        composer.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this);
        input.setHint("Message George…");
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        input.setMinLines(1);
        input.setMaxLines(5);
        input.setBackgroundColor(Color.rgb(24,32,38));
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        composer.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button send = button("Send");
        send.setOnClickListener(v -> sendMessage());
        composer.addView(send);
        root.addView(composer);
    }

    private void addBubble(String role, String content) {
        if (messages == null || chatScroll == null) return;
        TextView bubble = text(content, 16, Color.rgb(244,247,249));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(role.equals("user") ? dp(36) : 0, dp(4), role.equals("user") ? 0 : dp(36), dp(4));
        bubble.setBackgroundColor(role.equals("user") ? Color.rgb(32,49,60) : Color.rgb(24,39,45));
        messages.addView(bubble, lp);
        chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void sendMessage() {
        if (input == null) return;
        String msg = input.getText().toString().trim();
        if (msg.isEmpty()) return;

        final long chatId = currentChatId;
        final LinearLayout messageContainer = messages;
        input.setText("");
        db.addMessage(chatId, "user", msg);
        db.maybeAutoTitleChat(chatId, msg);
        addBubble("user", msg);
        if (chatTitleView != null && currentChatId == chatId) {
            chatTitleView.setText("💬 " + db.getChatTitle(chatId));
        }

        if (msg.toLowerCase(Locale.ROOT).startsWith("/remember ")) {
            String memory = msg.substring(10).trim();
            db.addMemory("explicit", "user_note", memory, 0.9);
            String answer = "Saved locally in George's long-term memory: “" + memory + "”";
            db.addMessage(chatId, "assistant", answer);
            addBubble("assistant", answer);
            return;
        }

        if (msg.equalsIgnoreCase("/memories")) {
            List<MemoryItem> items = db.getAllMemories();
            String answer = "I currently have " + items.size() + " local long-term memories. Open ☰ → Memory to review or delete them.";
            db.addMessage(chatId, "assistant", answer);
            addBubble("assistant", answer);
            return;
        }

        String apiKey = getApiKey();
        if (apiKey.isEmpty()) {
            String answer = "My local identity and memory are active, but the reasoning engine isn't connected yet. Open ☰ → AI connection. Your API key will be encrypted with Android Keystore and is not built into the APK.";
            db.addMessage(chatId, "assistant", answer);
            addBubble("assistant", answer);
            return;
        }

        TextView thinking = text("George is thinking…", 14, Color.LTGRAY);
        messageContainer.addView(thinking);
        executor.submit(() -> {
            try {
                List<MemoryItem> relevant = db.relevantMemories(msg, 12);
                List<String[]> history = db.recentMessages(chatId, 19);
                if (!history.isEmpty()) {
                    String[] last = history.get(history.size() - 1);
                    if ("user".equals(last[0]) && msg.equals(last[1])) history.remove(history.size() - 1);
                }
                if (history.size() > 18) history = history.subList(history.size() - 18, history.size());
                String model = getPreferences().getString("model", "gpt-5.6-luna");
                String answer = new OpenAIClient().respond(apiKey, model, georgeCore, relevant, history, msg);
                db.addMessage(chatId, "assistant", answer);
                runOnUiThread(() -> {
                    if (thinking.getParent() == messageContainer) messageContainer.removeView(thinking);
                    if (currentChatId == chatId && messages == messageContainer) addBubble("assistant", answer);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (thinking.getParent() == messageContainer) messageContainer.removeView(thinking);
                    if (currentChatId == chatId && messages == messageContainer) {
                        addBubble("assistant", "Connection error: " + e.getMessage());
                    }
                });
            }
        });
    }

    private void createNewChat() {
        currentChatId = db.createChat("New chat");
        saveCurrentChat();
        showChat();
    }

    private void switchToChat(long chatId) {
        if (!db.chatExists(chatId)) return;
        currentChatId = chatId;
        saveCurrentChat();
        showChat();
    }

    private void saveCurrentChat() {
        getPreferences().edit().putLong("current_chat_id", currentChatId).apply();
    }

    private void showChats() {
        baseScreen("Chats");
        root.addView(text("Each chat has its own short-term conversation history. George's long-term memory remains shared across all chats.", 14, Color.LTGRAY));

        Button newChat = button("＋ New chat");
        newChat.setOnClickListener(v -> createNewChat());
        root.addView(newChat);

        ScrollView sv = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        List<ChatItem> chats = db.getChats();
        SimpleDateFormat fmt = new SimpleDateFormat("dd MMM yyyy · HH:mm", Locale.getDefault());
        for (ChatItem chat : chats) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackgroundColor(chat.id == currentChatId ? Color.rgb(31,48,55) : Color.rgb(24,32,38));
            row.setPadding(dp(4), dp(4), dp(4), dp(4));

            TextView title = text(chat.title + "\n" + fmt.format(new Date(chat.updatedAt)), 15, Color.WHITE);
            title.setOnClickListener(v -> switchToChat(chat.id));
            row.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

            Button more = button("⋮");
            more.setOnClickListener(v -> showChatOptions(chat));
            row.addView(more);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(5), 0, dp(5));
            list.addView(row, lp);
        }
    }

    private void showChatOptions(ChatItem chat) {
        String[] options = {"Open", "Rename", "Delete"};
        new AlertDialog.Builder(this)
                .setTitle(chat.title)
                .setItems(options, (d, which) -> {
                    if (which == 0) switchToChat(chat.id);
                    else if (which == 1) renameChatDialog(chat);
                    else if (which == 2) confirmDeleteChat(chat);
                }).show();
    }

    private void renameChatDialog(ChatItem chat) {
        EditText title = new EditText(this);
        title.setText(chat.title);
        title.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
                .setTitle("Rename chat")
                .setView(title)
                .setPositiveButton("Save", (d, w) -> {
                    String value = title.getText().toString().trim();
                    if (!value.isEmpty()) db.renameChat(chat.id, value);
                    showChats();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmDeleteChat(ChatItem chat) {
        new AlertDialog.Builder(this)
                .setTitle("Delete chat?")
                .setMessage("This deletes only this conversation. George's long-term memory will not be deleted.")
                .setPositiveButton("Delete", (d, w) -> {
                    boolean wasCurrent = chat.id == currentChatId;
                    db.deleteChat(chat.id);
                    if (wasCurrent || !db.chatExists(currentChatId)) {
                        currentChatId = db.ensureDefaultChat();
                        saveCurrentChat();
                    }
                    showChats();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void clearCurrentChat() {
        new AlertDialog.Builder(this)
                .setTitle("Clear current chat?")
                .setMessage("Messages in this chat will be deleted. George's long-term memory will stay untouched.")
                .setPositiveButton("Clear", (d, w) -> {
                    db.clearMessages(currentChatId);
                    db.renameChat(currentChatId, "New chat");
                    showChat();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showMenu() {
        String[] options = {"New chat", "Chats", "Memory", "AI connection", "Identity core", "Export George", "Restore George", "Clear current chat"};
        new AlertDialog.Builder(this)
                .setTitle("George")
                .setItems(options, (d, which) -> {
                    switch (which) {
                        case 0: createNewChat(); break;
                        case 1: showChats(); break;
                        case 2: showMemory(); break;
                        case 3: showAiSettings(); break;
                        case 4: showCore(); break;
                        case 5: exportGeorge(); break;
                        case 6: importGeorge(); break;
                        case 7: clearCurrentChat(); break;
                    }
                }).show();
    }

    private void showMemory() {
        baseScreen("George Memory");
        TextView info = text("Long-term memories live in this phone's local SQLite database and are shared across all chats. Tap a memory to delete it.", 14, Color.LTGRAY);
        root.addView(info);
        ScrollView sv = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        List<MemoryItem> items = db.getAllMemories();
        if (items.isEmpty()) list.addView(text("No memories yet.", 16, Color.WHITE));
        for (MemoryItem m : items) {
            TextView row = text("[" + m.type + " · " + m.topic + "]\n" + m.content, 15, Color.WHITE);
            row.setBackgroundColor(Color.rgb(24,32,38));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(4), 0, dp(4));
            list.addView(row, lp);
            row.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Delete this memory?")
                    .setMessage(m.content)
                    .setPositiveButton("Delete", (d, w) -> { db.deleteMemory(m.id); showMemory(); })
                    .setNegativeButton("Cancel", null).show());
        }

        Button add = button("+ Add memory");
        add.setOnClickListener(v -> addMemoryDialog());
        root.addView(add);
    }

    private void addMemoryDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setPadding(dp(16), dp(8), dp(16), dp(8));
        form.setOrientation(LinearLayout.VERTICAL);
        EditText topic = new EditText(this); topic.setHint("Topic, e.g. JKVIN");
        EditText content = new EditText(this); content.setHint("What George should remember"); content.setMinLines(3);
        form.addView(topic); form.addView(content);
        new AlertDialog.Builder(this).setTitle("Add memory").setView(form)
                .setPositiveButton("Save", (d,w) -> {
                    String t = topic.getText().toString().trim();
                    String c = content.getText().toString().trim();
                    if (!c.isEmpty()) db.addMemory("manual", t.isEmpty() ? "general" : t, c, 0.8);
                    showMemory();
                }).setNegativeButton("Cancel", null).show();
    }

    private void showAiSettings() {
        baseScreen("AI connection");
        root.addView(text("Optional. George's memory remains local; this connects a replaceable cloud reasoning engine.", 15, Color.LTGRAY));

        EditText key = new EditText(this);
        key.setHint("OpenAI API key");
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        if (apiConfigured()) key.setHint("API key is stored securely — enter a new one to replace it");
        root.addView(key);

        EditText model = new EditText(this);
        model.setHint("Model");
        model.setText(getPreferences().getString("model", "gpt-5.6-luna"));
        root.addView(model);

        Button save = button("Save connection");
        save.setOnClickListener(v -> {
            try {
                String entered = key.getText().toString().trim();
                if (!entered.isEmpty()) secureStore.putSecret("openai_api_key", entered);
                getPreferences().edit().putString("model", model.getText().toString().trim()).apply();
                Toast.makeText(this, "Connection settings saved locally.", Toast.LENGTH_SHORT).show();
                showChat();
            } catch (Exception e) {
                Toast.makeText(this, "Could not secure key: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        root.addView(save);

        Button remove = button("Remove API key from phone");
        remove.setOnClickListener(v -> { secureStore.remove("openai_api_key"); Toast.makeText(this, "Key removed.", Toast.LENGTH_SHORT).show(); showAiSettings(); });
        root.addView(remove);

        root.addView(text("Note: OpenAI API usage is billed separately from a ChatGPT subscription. George defaults to gpt-5.6-luna to keep API cost lower; you can change the model here.", 13, Color.GRAY));
    }

    private void showCore() {
        baseScreen("George Core");
        ScrollView sv = new ScrollView(this);
        TextView core = text(georgeCore, 14, Color.WHITE);
        sv.addView(core);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(text("The identity core is separate from individual chat threads and long-term memory.", 12, Color.GRAY));
    }

    private void exportGeorge() {
        try {
            pendingExport = BackupCodec.exportJson(georgeCore, db.getAllMemories(), db);
            String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE, "George_Backup_" + date + ".json");
            startActivityForResult(i, REQ_EXPORT);
        } catch (Exception e) {
            Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void importGeorge() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_EXPORT && pendingExport != null) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                pendingExport = null;
                Toast.makeText(this, "George backup exported with memory and chats.", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQ_IMPORT) {
            try {
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri), StandardCharsets.UTF_8))) {
                    String line; while ((line = br.readLine()) != null) sb.append(line).append('\n');
                }
                new AlertDialog.Builder(this)
                        .setTitle("Restore George")
                        .setMessage("Replace current long-term memory and chat history with this backup? The API key is never imported.")
                        .setPositiveButton("Replace", (d,w) -> restoreJson(sb.toString(), true))
                        .setNegativeButton("Merge", (d,w) -> restoreJson(sb.toString(), false))
                        .setNeutralButton("Cancel", null).show();
            } catch (Exception e) {
                Toast.makeText(this, "Import failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void restoreJson(String json, boolean replace) {
        try {
            BackupCodec.ImportResult result = BackupCodec.importBackup(json, db, replace);
            if (!db.chatExists(currentChatId)) currentChatId = db.ensureDefaultChat();
            saveCurrentChat();
            Toast.makeText(this,
                    "Restored " + result.memories + " memories, " + result.chats + " chats and " + result.messages + " messages.",
                    Toast.LENGTH_LONG).show();
            showChat();
        } catch (Exception e) {
            Toast.makeText(this, "Restore failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void seedMemoriesIfNeeded() throws Exception {
        if (!db.getAllMemories().isEmpty()) return;
        JSONObject seed = new JSONObject(CoreLoader.readAsset(this, "memory_seed.json"));
        JSONArray arr = seed.optJSONArray("memories");
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject m = arr.getJSONObject(i);
            db.addMemory(m.optString("type", "memory"), m.optString("topic", "general"),
                    m.optString("content", ""), m.optDouble("importance", 0.5));
        }
    }

    private boolean apiConfigured() { return !getApiKey().isEmpty(); }

    private String getApiKey() {
        try { return secureStore.getSecret("openai_api_key"); }
        catch (Exception ignored) { return ""; }
    }

    private android.content.SharedPreferences getPreferences() {
        return getSharedPreferences("george_prefs", MODE_PRIVATE);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
