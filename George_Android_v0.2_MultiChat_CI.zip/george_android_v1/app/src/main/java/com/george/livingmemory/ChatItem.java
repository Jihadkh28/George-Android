package com.george.livingmemory;

public class ChatItem {
    public long id;
    public String title;
    public long createdAt;
    public long updatedAt;

    public ChatItem(long id, String title, long createdAt, long updatedAt) {
        this.id = id;
        this.title = title;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
}
