package com.george.livingmemory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class MemoryDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "george_memory.db";
    private static final int DB_VERSION = 2;

    public MemoryDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE memories (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "type TEXT NOT NULL," +
                "topic TEXT NOT NULL," +
                "content TEXT NOT NULL," +
                "importance REAL NOT NULL DEFAULT 0.5," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE chats (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE messages (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "chat_id INTEGER NOT NULL," +
                "role TEXT NOT NULL," +
                "content TEXT NOT NULL," +
                "created_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_messages_chat_id ON messages(chat_id, id)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            long now = System.currentTimeMillis();
            db.execSQL("CREATE TABLE IF NOT EXISTS chats (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "title TEXT NOT NULL," +
                    "created_at INTEGER NOT NULL," +
                    "updated_at INTEGER NOT NULL)");
            db.execSQL("INSERT OR IGNORE INTO chats(id,title,created_at,updated_at) VALUES(1,'Previous chat'," + now + "," + now + ")");
            try {
                db.execSQL("ALTER TABLE messages ADD COLUMN chat_id INTEGER NOT NULL DEFAULT 1");
            } catch (Exception ignored) {
                // Column may already exist if an interrupted migration is retried.
            }
            db.execSQL("UPDATE messages SET chat_id=1 WHERE chat_id IS NULL OR chat_id=0");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id, id)");
            try {
                db.execSQL("UPDATE chats SET updated_at=COALESCE((SELECT MAX(created_at) FROM messages WHERE chat_id=1), updated_at) WHERE id=1");
            } catch (Exception ignored) {
            }
        }
    }

    public long addMemory(String type, String topic, String content, double importance) {
        long now = System.currentTimeMillis();
        return addMemoryWithTimestamps(type, topic, content, importance, now, now);
    }

    public long addMemoryWithTimestamps(String type, String topic, String content, double importance,
                                        long createdAt, long updatedAt) {
        ContentValues v = new ContentValues();
        v.put("type", type);
        v.put("topic", topic);
        v.put("content", content);
        v.put("importance", Math.max(0.0, Math.min(1.0, importance)));
        v.put("created_at", createdAt > 0 ? createdAt : System.currentTimeMillis());
        v.put("updated_at", updatedAt > 0 ? updatedAt : System.currentTimeMillis());
        return getWritableDatabase().insert("memories", null, v);
    }

    public void updateMemory(long id, String type, String topic, String content, double importance) {
        ContentValues v = new ContentValues();
        v.put("type", type);
        v.put("topic", topic);
        v.put("content", content);
        v.put("importance", Math.max(0.0, Math.min(1.0, importance)));
        v.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().update("memories", v, "id=?", new String[]{String.valueOf(id)});
    }

    public void deleteMemory(long id) {
        getWritableDatabase().delete("memories", "id=?", new String[]{String.valueOf(id)});
    }

    public List<MemoryItem> getAllMemories() {
        List<MemoryItem> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,type,topic,content,importance,created_at,updated_at FROM memories ORDER BY importance DESC, updated_at DESC",
                null)) {
            while (c.moveToNext()) {
                out.add(new MemoryItem(
                        c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                        c.getDouble(4), c.getLong(5), c.getLong(6)));
            }
        }
        return out;
    }

    public List<MemoryItem> relevantMemories(String query, int limit) {
        List<MemoryItem> all = getAllMemories();
        String cleaned = query.toLowerCase().replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
        String[] words = cleaned.isEmpty() ? new String[0] : cleaned.split("\\s+");
        all.sort((a, b) -> Double.compare(score(b, words), score(a, words)));
        if (all.size() > limit) return new ArrayList<>(all.subList(0, limit));
        return all;
    }

    private double score(MemoryItem m, String[] words) {
        String text = (m.topic + " " + m.content + " " + m.type).toLowerCase();
        double score = m.importance * 2.0;
        for (String w : words) {
            if (w.length() >= 3 && text.contains(w)) score += 1.0;
        }
        return score;
    }

    public long ensureDefaultChat() {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM chats ORDER BY updated_at DESC, id DESC LIMIT 1", null)) {
            if (c.moveToFirst()) return c.getLong(0);
        }
        return createChat("New chat");
    }

    public boolean chatExists(long chatId) {
        if (chatId <= 0) return false;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT 1 FROM chats WHERE id=? LIMIT 1", new String[]{String.valueOf(chatId)})) {
            return c.moveToFirst();
        }
    }

    public long createChat(String title) {
        long now = System.currentTimeMillis();
        return createChatWithTimestamps(title, now, now);
    }

    public long createChatWithTimestamps(String title, long createdAt, long updatedAt) {
        ContentValues v = new ContentValues();
        v.put("title", normalizeTitle(title));
        v.put("created_at", createdAt > 0 ? createdAt : System.currentTimeMillis());
        v.put("updated_at", updatedAt > 0 ? updatedAt : System.currentTimeMillis());
        return getWritableDatabase().insert("chats", null, v);
    }

    public List<ChatItem> getChats() {
        List<ChatItem> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,title,created_at,updated_at FROM chats ORDER BY updated_at DESC, id DESC", null)) {
            while (c.moveToNext()) {
                out.add(new ChatItem(c.getLong(0), c.getString(1), c.getLong(2), c.getLong(3)));
            }
        }
        return out;
    }

    public ChatItem getChat(long chatId) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,title,created_at,updated_at FROM chats WHERE id=? LIMIT 1",
                new String[]{String.valueOf(chatId)})) {
            if (c.moveToFirst()) {
                return new ChatItem(c.getLong(0), c.getString(1), c.getLong(2), c.getLong(3));
            }
        }
        return null;
    }

    public String getChatTitle(long chatId) {
        ChatItem item = getChat(chatId);
        return item == null ? "New chat" : item.title;
    }

    public void renameChat(long chatId, String title) {
        ContentValues v = new ContentValues();
        v.put("title", normalizeTitle(title));
        v.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().update("chats", v, "id=?", new String[]{String.valueOf(chatId)});
    }

    public void deleteChat(long chatId) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            writable.delete("messages", "chat_id=?", new String[]{String.valueOf(chatId)});
            writable.delete("chats", "id=?", new String[]{String.valueOf(chatId)});
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    public void clearChats() {
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            writable.delete("messages", null, null);
            writable.delete("chats", null, null);
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    public void maybeAutoTitleChat(long chatId, String firstUserMessage) {
        ChatItem chat = getChat(chatId);
        if (chat == null) return;
        if (!"New chat".equalsIgnoreCase(chat.title) && !"Previous chat".equalsIgnoreCase(chat.title)) return;
        if (countUserMessages(chatId) != 1) return;

        String title = firstUserMessage == null ? "New chat" : firstUserMessage.replaceAll("\\s+", " ").trim();
        if (title.isEmpty()) return;
        if (title.length() > 42) title = title.substring(0, 42).trim() + "…";
        renameChat(chatId, title);
    }

    private int countUserMessages(long chatId) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM messages WHERE chat_id=? AND role='user'",
                new String[]{String.valueOf(chatId)})) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public long addMessage(long chatId, String role, String content) {
        return addMessageWithTimestamp(chatId, role, content, System.currentTimeMillis());
    }

    public long addMessageWithTimestamp(long chatId, String role, String content, long createdAt) {
        ContentValues v = new ContentValues();
        v.put("chat_id", chatId);
        v.put("role", role);
        v.put("content", content);
        long timestamp = createdAt > 0 ? createdAt : System.currentTimeMillis();
        v.put("created_at", timestamp);
        long id = getWritableDatabase().insert("messages", null, v);
        ContentValues touch = new ContentValues();
        touch.put("updated_at", timestamp);
        getWritableDatabase().update("chats", touch, "id=?", new String[]{String.valueOf(chatId)});
        return id;
    }

    public List<String[]> recentMessages(long chatId, int limit) {
        List<String[]> reversed = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT role,content FROM messages WHERE chat_id=? ORDER BY id DESC LIMIT ?",
                new String[]{String.valueOf(chatId), String.valueOf(limit)})) {
            while (c.moveToNext()) reversed.add(new String[]{c.getString(0), c.getString(1)});
        }
        List<String[]> ordered = new ArrayList<>();
        for (int i = reversed.size() - 1; i >= 0; i--) ordered.add(reversed.get(i));
        return ordered;
    }

    public List<String[]> allMessagesForBackup(long chatId) {
        List<String[]> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT role,content,created_at FROM messages WHERE chat_id=? ORDER BY id ASC",
                new String[]{String.valueOf(chatId)})) {
            while (c.moveToNext()) {
                out.add(new String[]{c.getString(0), c.getString(1), String.valueOf(c.getLong(2))});
            }
        }
        return out;
    }

    public void clearMessages(long chatId) {
        getWritableDatabase().delete("messages", "chat_id=?", new String[]{String.valueOf(chatId)});
        ContentValues touch = new ContentValues();
        touch.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().update("chats", touch, "id=?", new String[]{String.valueOf(chatId)});
    }

    public void clearMemories() {
        getWritableDatabase().delete("memories", null, null);
    }

    private String normalizeTitle(String title) {
        String t = title == null ? "" : title.replaceAll("\\s+", " ").trim();
        if (t.isEmpty()) t = "New chat";
        if (t.length() > 60) t = t.substring(0, 60).trim() + "…";
        return t;
    }
}
