package com.george.livingmemory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class OpenAIClient {
    private static final String ENDPOINT = "https://api.openai.com/v1/responses";

    public String respond(String apiKey, String model, String core,
                          List<MemoryItem> memories, List<String[]> history,
                          String currentMessage) throws Exception {
        StringBuilder context = new StringBuilder();
        context.append(core).append("\n\n# Relevant local memories\n");
        for (MemoryItem m : memories) {
            context.append("- [").append(m.type).append("/").append(m.topic).append("] ")
                    .append(m.content).append("\n");
        }
        context.append("\n# Recent local conversation\n");
        for (String[] msg : history) {
            context.append(msg[0]).append(": ").append(msg[1]).append("\n");
        }

        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("store", false);
        body.put("instructions", context.toString());
        body.put("input", currentMessage);

        HttpURLConnection conn = (HttpURLConnection) new URL(ENDPOINT).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(90000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json");

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        String raw = readAll(stream);
        if (code < 200 || code >= 300) {
            throw new Exception("OpenAI API error " + code + ": " + extractError(raw));
        }

        JSONObject json = new JSONObject(raw);
        JSONArray output = json.optJSONArray("output");
        if (output != null) {
            StringBuilder answer = new StringBuilder();
            for (int i = 0; i < output.length(); i++) {
                JSONObject item = output.optJSONObject(i);
                if (item == null || !"message".equals(item.optString("type"))) continue;
                JSONArray content = item.optJSONArray("content");
                if (content == null) continue;
                for (int j = 0; j < content.length(); j++) {
                    JSONObject c = content.optJSONObject(j);
                    if (c != null && "output_text".equals(c.optString("type"))) {
                        if (answer.length() > 0) answer.append("\n");
                        answer.append(c.optString("text"));
                    }
                }
            }
            if (answer.length() > 0) return answer.toString();
        }
        return "I received a response, but could not extract the text.";
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private String extractError(String raw) {
        try {
            JSONObject j = new JSONObject(raw);
            JSONObject e = j.optJSONObject("error");
            return e != null ? e.optString("message", raw) : raw;
        } catch (Exception ignored) {
            return raw;
        }
    }
}
