# George v1 uses only Android platform APIs.
